public class CAH_ApprovalDetailsTriggerHandler {
		
    
    public void isUpdateOrInsert(List<CoraAP__Approval_Detail__c> approverDetails){
    Map<String,String> appverEmailMap=new Map<String,String>();
    Map<String,CoraAP__Invoice__c> invoiceMap= new Map<String,CoraAP__Invoice__c>();
        List<id> invIds=new List<id>();
        for(CoraAP__Approval_Detail__c approvalDetails:approverDetails){
             invIds.add(approvalDetails.coraAP__invoice__C);
        }
        
        List<CoraAP__Approval_Detail__c> approvalDetails=[select id,CoraAP__Status__c,coraAP__invoice__r.CAH_Is_Approver_Chain_Complete__c,coraAP__invoice__r.CAH_Is_Pre_Approved__c,coraAP__invoice__r.CAH_Is_DOA_Success__c, CoraAP__AP_Approver_Type__c,
                        CAH_Is_Buyer_Portal_Record__c, CoraAP__Invoice__c,CoraAP__Approver_User__r.CoraAP__Email__c,
                        CAH_Approver_Email__c  from CoraAP__Approval_Detail__c where coraAP__invoice__C in:invIds and CoraAP__Status__c in ('Pending','Approved') 
                       and  coraAP__invoice__r.CoraAP__Current_State__c = 'Awaiting CAH Supervisory Approval' 
                AND coraAP__invoice__r.CoraAP__Document_Type__c = 'Direct Non PO Invoice' 
                AND coraAP__invoice__r.CAH_Tower__c in('Pharma','Medical') order by createddate asc];
       system.debug('PK____ 19 : '+approvalDetails);
        if(approvalDetails!=null && approvalDetails.size()>1){
            for(CoraAP__Approval_Detail__c appDetail: approvalDetails){
                if(appDetail.CoraAP__Status__c=='Approved' && appDetail.CoraAP__Approver_User__c!=null){
                   appverEmailMap.put(appDetail.coraAP__invoice__c+appDetail.CoraAP__Approver_User__r.CoraAP__Email__c,appDetail.CoraAP__Approver_User__r.CoraAP__Email__c);
                    system.debug('PK____ 23 : '+approvalDetails);
                    //appverEmailId.add(appDetail.CAH_Approver_Email__c);
                }
            }
        }
        system.debug('Approver Email ID Log <<>>'+ appverEmailMap);
        if(appverEmailMap!=null && appverEmailMap.size()>0){
             for(CoraAP__Approval_Detail__c appDetail: approvalDetails){
                 system.debug('CAH approver email id log >> '+appDetail.CAH_Approver_Email__c);
                 if(appDetail.CoraAP__Status__c=='Pending'  && appverEmailMap.get(appDetail.coraAP__invoice__c+appDetail.CAH_Approver_Email__c)!=null){
                     CoraAP__Invoice__c inv = new CoraAP__Invoice__c(Id = appDetail.CoraAP__Invoice__c,CoraAP__User_Action__c = 'Approve',CAH_Complete__c = 1);
						
                     invoiceMap.put(appDetail.CoraAP__Invoice__c,inv);
                       system.debug('PK____ 23 : '+invoiceMap);
                     Break;	
                 }else if(appDetail.CoraAP__Status__c=='Pending'){
                      CoraAP__Invoice__c inv = new CoraAP__Invoice__c(Id = appDetail.CoraAP__Invoice__c,CAH_Complete__c = 0);
					  invoiceMap.put(appDetail.CoraAP__Invoice__c,inv);	
                 }
             }
        }
        if(approvalDetails!=null && approvalDetails.size()>1){
            for(CoraAP__Approval_Detail__c appDetails: approvalDetails){
                if(appDetails.CoraAP__Status__c=='Approved' && appDetails.coraAP__invoice__r.CAH_Is_DOA_Success__c 
                   && appDetails.coraAP__invoice__r.CAH_Is_Approver_Chain_Complete__c){
                      CoraAP__Invoice__c inv = new CoraAP__Invoice__c(Id = appDetails.CoraAP__Invoice__c,CAH_Is_Pre_Approved__c=true,CoraAP__User_Action__c = 'Approve',CAH_Complete__c = 1);
						
                     invoiceMap.put(appDetails.CoraAP__Invoice__c,inv);
                       break;
                }
            }
        }
        
        system.debug('invoiceMap log>>'+invoiceMap);
        if(invoiceMap!=null && invoiceMap.size()>0){
       		update invoiceMap.values();
        }
        
       
    }
}